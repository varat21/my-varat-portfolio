/** Canonical profile links */
export const LINKEDIN_URL =
  "https://www.linkedin.com/in/varat-thapa-606a0a122/";
export const GITHUB_URL = "https://github.com/varat-thapa";
export const HACKERRANK_SQL_CERT_URL =
  "https://www.hackerrank.com/certificates/633d834e0512";

export const siteConfig = {
  name: "Hari Thapa",
  role: "Frontend Developer | React & Next.js",
  roleTitles: [
    "Frontend Developer",
    "React & Next.js Developer",
    "Full-Stack Developer",
  ],
  email: "varat.thapa21@gmail.com",
  location: "Kathmandu, Bagmati, Nepal",
  tagline:
    "React, Next.js,Data Science and Python.",
  bio: "I'm a Full-Stack Developer with expertise in React, Next.js, and Python. I specialize in responsive UIs, REST API integration, and full-stack workflows—from dashboards at Everest Technologies to the NHEA nonprofit web platform and the longevity & wellness product at ExtendMy.Life. I enjoy turning real-world requirements into clean, maintainable code.",
  resumeUrl: "/resume.pdf",
  linkedIn: LINKEDIN_URL,
  github: GITHUB_URL,
  socials: [
    {
      name: "LinkedIn",
      url: LINKEDIN_URL,
      icon: "linkedin" as const,
      primary: true,
    },
    {
      name: "GitHub",
      url: GITHUB_URL,
      icon: "github" as const,
      primary: false,
    },
  ],
};

export const navLinks = [
  { name: "About", href: "#about" },
  { name: "Education", href: "#education" },
  { name: "Certifications", href: "#certifications" },
  { name: "Projects", href: "#projects" },
  { name: "Experience", href: "#experience" },
  { name: "Testimonials", href: "#testimonials" },
  { name: "Contact", href: "#contact" },
];

export const skills = [
  "React.js",
  "Next.js",
  "TypeScript",
  "JavaScript",
  "Data science with python",
  "PHP",
  "MySQL",
  "Tailwind CSS",
  "Vite",
  "Git",
  "GitHub",
  
  "SQL",
  "Dashboard Design",
  "Full-Stack Development",
  "Web Development",
];

export const stats = [
  { value: "2+", label: "Years Experience" },
  { value: "6+", label: "Projects Shipped" },
  { value: "3", label: "Current Roles" },
  { value: "3", label: "Certification" },
];

export const educationList = [
  {
    id: "tu-mbait",
    degree: "MBA IT (Master of Business Administration in Information Technology)",
    school: "School of Management, Tribhuvan University",
    location: "Kathmandu, Nepal",
    period: "In Progress",
    status: "in-progress" as const,
    field: "Information Technology & Management",
    detail:
      "Currently pursuing MBA IT at Tribhuvan University's School of Management, combining business administration with information technology, systems thinking, and IT-driven organizational strategy.",
    highlights: [
      "IT management and business strategy integration",
      "Information systems and technology leadership",
      "Applied learning alongside professional development work",
    ],
  },
  {
    id: "london-met",
    degree: "BSc (Hons) in Computing",
    school: "London Metropolitan University",
    location: "Informatic College Of Pokhara, Pokhara, Nepal",
    period: "2022 — 2025",
    field: "Computer Programming / General Computing",
    detail:
      "Honours bachelor's degree in computing from a London-based university, with coursework and projects in software development, programming, and modern web technologies.",
    highlights: [
      "Software development and programming fundamentals",
      "Web application design and implementation",
      "Database systems and practical computing projects",
    ],
  },
];

export const certifications = [
  {
    title: "HackerRank SQL Certification",
    issuer: "HackerRank",
    date: "January 2026",
    url: HACKERRANK_SQL_CERT_URL,
  },
];

export const achievements = [
  {
    title: "HackerRank SQL Certified",
    year: "2026",
    description:
      "Earned HackerRank SQL certification, strengthening data querying and backend integration skills.",
  },
  {
    title: "NHEA Web Platform",
    year: "2025",
    description:
      "Delivered Next.js web applications for Nepal Health Economics Association, supporting nonprofit health economics initiatives.",
  },
  {
    title: "Full-Stack Localhost App",
    year: "2025",
    description:
      "Built end-to-end React + PHP + MySQL application with authentication, CRUD, and REST API integration on XAMPP.",
  },
];

export const projects = [
  {
    id: "nhea",
    title: "NHEA Web Platform",
    description:
      "Next.js web application for Nepal Health Economics Association — supporting nonprofit health economics research and public-facing content at nheanepal.org.",
    image: "/images/project2.png",
    gradient: "from-sky-500/20 via-blue-600/10 to-transparent",
    tech: ["Next.js", "TypeScript", "Tailwind CSS"],
    liveUrl: "https://nheanepal.org",
    demoUrl: GITHUB_URL,
    featured: true,
  },
  {
    id: "restropoint",
    title: "Restropoint",
    description:
      "Restaurant management system with reservations, inventory, billing, and staff management — built for fast, user-friendly hospitality operations.",
    image: "/images/project1.png",
    gradient: "from-amber-500/20 via-orange-600/10 to-transparent",
    tech: ["React", "Mantine", "Tailwind CSS"],
    liveUrl: "#",
    demoUrl: GITHUB_URL,
    featured: true,
  },
  {
    id: "fullstack-php",
    title: "React + PHP + MySQL App",
    description:
      "Full-stack localhost app with user auth, CRUD operations, responsive Tailwind UI, and REST API communication between React (Vite) and PHP on XAMPP.",
    image: "/images/logos/python.svg",
    gradient: "from-emerald-500/20 via-teal-600/10 to-transparent",
    tech: ["React", "PHP", "MySQL", "Tailwind CSS"],
    liveUrl: "#",
    demoUrl: GITHUB_URL,
    featured: true,
  },
  // {
  //   id: "nheanepal",
  //   title: "Nepal Health Economic Association",
  //   description:
  //     "Next.js TypeScript web application developed as part of IT and web development support for Nepal Health Economics Association.",
  //   image: "",
  //   gradient: "from-violet-500/20 via-purple-600/10 to-transparent",
  //   tech: ["Next.js", "TypeScript", "React"],
  //   liveUrl: "#",
  //   demoUrl: GITHUB_URL,
  //   featured: false,
  // },
  {
    id: "everest-dashboard",
    title: "React Analytics Dashboard",
    description:
      "Interactive dashboard built with React and Axios for API integration during internship at Everest Technologies, Pokhara.",
    image: "/images/project3.png",
    gradient: "from-rose-500/20 via-pink-600/10 to-transparent",
    tech: ["React", "Axios", "REST APIs"],
    liveUrl: "#",
    demoUrl: GITHUB_URL,
    featured: false,
  },
  // {
  //   id: "extendmylife",
  //   title: "ExtendMy.Life Platform",
  //   description:
  //     "Contributing to a longevity and wellness platform as Frontend Developer — React & Next.js interfaces for health-focused product experiences.",
  //   image: "/images/Gemini_Generated_Image_m2k2y3m2k2y3m2k2.png",
  //   gradient: "from-cyan-500/20 via-indigo-600/10 to-transparent",
  //   tech: ["React", "Next.js", "TypeScript"],
  //   liveUrl: "#",
  //   demoUrl: LINKEDIN_URL,
  //   featured: false,
  // },
];

export const experience = [
  // {
  //   id: "extendmylife",
  //   company: "ExtendMy.Life",
  //   role: "Frontend Developer",
  //   period: "Present",
  //   location: "Remote / Nepal",
  //   logo: "/images/Gemini_Generated_Image_m2k2y3m2k2y3m2k2.png",
  //   description:
  //     "Building the longevity and wellness platform at extendMy.Life using React and Next.js for modern, performance-focused user experiences.",
  //   highlights: [
  //     "Develop frontend features for a health and longevity-focused product",
  //     "Work with React and Next.js in a fast-moving product environment",
  //     "Collaborate on UI aligned with wellness and executive-health use cases",
  //   ],
  // },
  //
  {
    id: "nhea",
    company: "Nepal Health Economics Association",
    role: "IT & Web Development Support Consultant",
    period: "Nov 2025 — Present",
    location: "Kathmandu, Nepal",
    logo: "/images/logo1.png",
    description:
      "IT and web development support for a nonprofit focused on health economics in Nepal, including Next.js applications and organizational web presence.",
    highlights: [
      "Build and maintain Next.js / TypeScript web applications (NHEA)",
      "Support nonprofit digital infrastructure and web development needs",
      "Integrate APIs and deliver responsive, accessible interfaces",
    ],
  },
  {
    id: "everest",
    company: "Everest Technologies",
    role: "Internship Trainee",
    period: "Aug 2024 — Present",
    location: "Pokhara, Gandaki, Nepal",
    logo: "/images/logo3.png",
    description:
      "IT solutions internship at an Pokhara-based company providing custom software, support, and programming training.",
    highlights: [
      "Built dashboards using React and Axios for API integration",
      "Gained hands-on experience in full-stack web development workflows",
      "Contributed to client-focused software solutions and internal tools",
    ],
  },
];

export const testimonials = [
  {
    id: "colleague-nhea",
    name: "NHEA Collaborator",
    handle: "Nonprofit Tech",
    quote:
      "Varat delivered reliable Next.js work for our association's web needs. He communicates clearly and ships practical solutions on deadline.",
    avatar: "/images/client2.png",
  },
  {
    id: "mentor-everest",
    name: "Everest Technologies Team",
    handle: "Pokhara, Nepal",
    quote:
      "During his internship, Varat built solid React dashboards with clean API integration. He's eager to learn and executes well on assigned features.",
    avatar: "/images/client3.png",
  },
  {
    id: "peer-dev",
    name: "Fellow Developer",
    handle: "Full-Stack Projects",
    quote:
      "His React + PHP + MySQL project shows strong full-stack fundamentals — auth, CRUD, and a well-structured codebase. Great collaborator on web builds.",
    avatar: "/images/client4.png",
  },
];

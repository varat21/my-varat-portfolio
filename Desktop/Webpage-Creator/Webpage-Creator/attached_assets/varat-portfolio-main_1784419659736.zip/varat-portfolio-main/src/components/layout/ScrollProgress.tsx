import { motion } from "framer-motion";
import { useScrollProgress } from "@/hooks/useScrollProgress";

export function ScrollProgress() {
  const progress = useScrollProgress();

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 z-[90] h-[2px] origin-left bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)]"
      style={{ scaleX: progress }}
      aria-hidden
    />
  );
}

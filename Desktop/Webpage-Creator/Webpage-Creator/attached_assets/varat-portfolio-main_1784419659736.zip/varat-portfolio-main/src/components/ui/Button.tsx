import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "@/utils/cn";

type ButtonProps = HTMLMotionProps<"button"> & {
  variant?: "primary" | "ghost" | "outline";
  href?: string;
};

export function Button({
  className,
  variant = "primary",
  children,
  href,
  ...props
}: ButtonProps) {
  const base = cn(
    "relative inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent)]",
    variant === "primary" &&
      "bg-[var(--accent)] text-[var(--accent-foreground)] hover:brightness-110",
    variant === "ghost" &&
      "text-[var(--foreground)] hover:bg-[var(--glass-hover)]",
    variant === "outline" &&
      "border border-[var(--border)] bg-[var(--glass)] text-[var(--foreground)] backdrop-blur-md hover:border-[var(--accent)]/50",
    className
  );

  const motionProps = {
    whileHover: { scale: 1.02 },
    whileTap: { scale: 0.98 },
    transition: { type: "spring" as const, stiffness: 400, damping: 25 },
  };

  if (href) {
    return (
      <motion.a
        href={href}
        className={base}
        whileHover={motionProps.whileHover}
        whileTap={motionProps.whileTap}
        transition={motionProps.transition}
        aria-label={typeof children === "string" ? children : undefined}
      >
        {children}
      </motion.a>
    );
  }

  return (
    <motion.button className={base} {...motionProps} {...props}>
      {children}
    </motion.button>
  );
}

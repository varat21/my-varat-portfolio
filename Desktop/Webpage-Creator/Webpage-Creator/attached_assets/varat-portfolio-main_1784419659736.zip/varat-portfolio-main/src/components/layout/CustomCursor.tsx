import { motion, useSpring } from "framer-motion";
import { useEffect, useState } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { useMousePosition } from "@/hooks/useMousePosition";

export function CustomCursor() {
  const isDesktop = useMediaQuery("(min-width: 1024px) and (pointer: fine)");
  const { x, y } = useMousePosition(isDesktop);
  const [hovering, setHovering] = useState(false);

  const springConfig = { damping: 28, stiffness: 280, mass: 0.5 };
  const cursorX = useSpring(0, springConfig);
  const cursorY = useSpring(0, springConfig);
  const ringX = useSpring(0, { ...springConfig, stiffness: 180 });
  const ringY = useSpring(0, { ...springConfig, stiffness: 180 });

  useEffect(() => {
    if (!isDesktop) return;
    cursorX.set(x);
    cursorY.set(y);
    ringX.set(x);
    ringY.set(y);
  }, [x, y, isDesktop, cursorX, cursorY, ringX, ringY]);

  useEffect(() => {
    if (!isDesktop) return;

    const onOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      setHovering(
        !!target.closest("a, button, [role='button'], input, textarea, label")
      );
    };

    document.addEventListener("mouseover", onOver);
    return () => document.removeEventListener("mouseover", onOver);
  }, [isDesktop]);

  if (!isDesktop) return null;

  return (
    <>
      <motion.div
        className="pointer-events-none fixed top-0 left-0 z-[9999] mix-blend-difference"
        style={{ x: cursorX, y: cursorY, translateX: "-50%", translateY: "-50%" }}
        aria-hidden
      >
        <div className="h-2 w-2 rounded-full bg-white" />
      </motion.div>
      <motion.div
        className="pointer-events-none fixed top-0 left-0 z-[9998] rounded-full border border-[var(--accent)]/60"
        style={{
          x: ringX,
          y: ringY,
          translateX: "-50%",
          translateY: "-50%",
          width: hovering ? 48 : 32,
          height: hovering ? 48 : 32,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        aria-hidden
      />
    </>
  );
}

import { motion, type Variants } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

const container: Variants = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.1, delayChildren: 0.05 },
  },
};

const item: Variants = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
};

type RevealProps = {
  children: ReactNode;
  className?: string;
  as?: "div" | "section" | "ul";
  stagger?: boolean;
};

export function Reveal({
  children,
  className,
  as = "div",
  stagger = false,
}: RevealProps) {
  const Component = motion[as];

  return (
    <Component
      className={cn(className)}
      variants={stagger ? container : item}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-60px" }}
    >
      {stagger
        ? children
        : (
            <motion.div variants={item}>{children}</motion.div>
          )}
    </Component>
  );
}

export function RevealItem({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.div className={cn(className)} variants={item}>
      {children}
    </motion.div>
  );
}

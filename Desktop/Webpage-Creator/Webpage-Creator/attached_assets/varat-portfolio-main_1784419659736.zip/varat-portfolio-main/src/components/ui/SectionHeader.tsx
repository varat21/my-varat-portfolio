import { motion } from "framer-motion";
import { cn } from "@/utils/cn";

type SectionHeaderProps = {
  label: string;
  title: string;
  description?: string;
  className?: string;
};

export function SectionHeader({
  label,
  title,
  description,
  className,
}: SectionHeaderProps) {
  return (
    <motion.header
      className={cn("mx-auto max-w-3xl text-center", className)}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <span className="mb-4 inline-block rounded-full border border-[var(--border)] bg-[var(--glass)] px-4 py-1.5 text-xs font-medium tracking-widest text-[var(--accent)] uppercase backdrop-blur-md">
        {label}
      </span>
      <h2 className="text-3xl font-semibold tracking-tight text-[var(--foreground)] sm:text-4xl md:text-5xl">
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-base leading-relaxed text-[var(--muted)] sm:text-lg">
          {description}
        </p>
      )}
    </motion.header>
  );
}

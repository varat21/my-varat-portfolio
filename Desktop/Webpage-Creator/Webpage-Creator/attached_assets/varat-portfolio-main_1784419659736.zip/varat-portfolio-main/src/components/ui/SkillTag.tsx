import { motion } from "framer-motion";

type SkillTagProps = {
  skill: string;
  index: number;
};

export function SkillTag({ skill, index }: SkillTagProps) {
  return (
    <motion.li
      className="interactive cursor-default rounded-full border border-[var(--border)] bg-[var(--glass)] px-4 py-2 text-sm text-[var(--foreground)] backdrop-blur-md transition-colors hover:border-[var(--accent)]/40 hover:bg-[var(--glass-hover)]"
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.03, duration: 0.4 }}
      whileHover={{ scale: 1.05, y: -2 }}
    >
      {skill}
    </motion.li>
  );
}

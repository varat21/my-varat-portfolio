import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef } from "react";
import type { projects } from "@/data/portfolio";
import { cn } from "@/utils/cn";

type Project = (typeof projects)[number];

type ProjectCardProps = {
  project: Project;
  index: number;
};

export function ProjectCard({ project, index }: ProjectCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [8, -8]), {
    stiffness: 300,
    damping: 30,
  });
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-8, 8]), {
    stiffness: 300,
    damping: 30,
  });

  const handleMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    x.set(px);
    y.set(py);
  };

  const handleLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.article
      ref={ref}
      className="group relative"
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{ perspective: 1000 }}
    >
      <motion.div
        className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)] backdrop-blur-xl"
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
      >
        <div
          className={cn(
            "absolute inset-0 bg-gradient-to-br opacity-60",
            project.gradient
          )}
          aria-hidden
        />
        <div
          className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{
            background:
              "linear-gradient(135deg, var(--accent) 0%, transparent 50%, var(--accent-secondary) 100%)",
            padding: "1px",
            WebkitMask:
              "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          }}
          aria-hidden
        />

        <div className="relative aspect-[16/10] overflow-hidden">
          <img
            src={project.image}
            alt=""
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
            decoding="async"
            onError={(e) => {
              const target = e.currentTarget;
              target.style.display = "none";
            }}
          />
          <div
            className={cn(
              "absolute inset-0 flex items-center justify-center bg-gradient-to-br",
              project.gradient
            )}
          >
            <span className="text-4xl font-bold text-[var(--foreground)]/20">
              {project.title.charAt(0)}
            </span>
          </div>
        </div>

        <div className="relative p-6">
          <h3 className="text-xl font-semibold text-[var(--foreground)]">
            {project.title}
          </h3>
          <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-[var(--muted)]">
            {project.description}
          </p>
          <ul className="mt-4 flex flex-wrap gap-2" aria-label="Technologies">
            {project.tech.map((t) => (
              <li
                key={t}
                className="rounded-full border border-[var(--border)] bg-[var(--glass)] px-2.5 py-0.5 text-xs text-[var(--muted)]"
              >
                {t}
              </li>
            ))}
          </ul>
          <div className="mt-5 flex gap-3">
            <a
              href={project.liveUrl}
              className="interactive text-sm font-medium text-[var(--accent)] hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent)]"
              target="_blank"
              rel="noopener noreferrer"
            >
              Live
            </a>
            <a
              href={project.demoUrl}
              className="interactive text-sm font-medium text-[var(--muted)] hover:text-[var(--foreground)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent)]"
              target="_blank"
              rel="noopener noreferrer"
            >
              Source
            </a>
          </div>
        </div>
      </motion.div>
    </motion.article>
  );
}

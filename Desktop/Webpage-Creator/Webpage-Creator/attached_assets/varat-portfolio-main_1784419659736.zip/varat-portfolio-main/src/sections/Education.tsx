import { motion } from "framer-motion";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { certifications, educationList } from "@/data/portfolio";

export function Education() {
  return (
    <section
      id="education"
      className="section-padding"
      aria-labelledby="education-heading"
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <SectionHeader
          label="Education"
          title="Academic background"
          description="Formal training in computing and continuous learning through certifications."
        />
        <h2 id="education-heading" className="sr-only">
          Education and certifications
        </h2>

        <ol className="relative mt-16 space-y-0">
          <div
            className="absolute top-0 bottom-0 left-6 w-px bg-gradient-to-b from-[var(--accent)] via-[var(--border)] to-transparent md:left-1/2 md:-translate-x-px"
            aria-hidden
          />
          {educationList.map((item, index) => (
            <motion.li
              key={item.id}
              className="relative grid gap-8 pb-16 md:grid-cols-2 md:gap-12"
              initial={{ opacity: 0, x: index % 2 === 0 ? -24 : 24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div
                className={`md:col-span-1 ${index % 2 === 1 ? "md:order-2 md:text-left" : "md:text-right"}`}
              >
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-medium text-[var(--accent)]">
                    {item.period}
                  </span>
                  {"status" in item && item.status === "in-progress" && (
                    <span className="rounded-full border border-[var(--accent)]/40 bg-[var(--accent)]/10 px-2.5 py-0.5 text-xs font-medium text-[var(--accent)]">
                      Ongoing
                    </span>
                  )}
                </div>
                <h3 className="mt-1 text-xl font-semibold text-[var(--foreground)]">
                  {item.degree}
                </h3>
                <p className="font-medium text-[var(--muted)]">{item.school}</p>
                <p className="mt-1 text-sm text-[var(--muted)]/80">{item.location}</p>
                <p className="mt-2 text-sm text-[var(--accent)]">{item.field}</p>
              </div>

              <div
                className={`glass-card rounded-2xl p-6 md:col-span-1 ${index % 2 === 1 ? "md:order-1" : ""}`}
              >
                <p className="text-sm leading-relaxed text-[var(--muted)]">
                  {item.detail}
                </p>
                {item.highlights && (
                  <ul className="mt-4 space-y-2 text-sm text-[var(--foreground)]/90">
                    {item.highlights.map((h) => (
                      <li key={h} className="flex gap-2">
                        <span className="text-[var(--accent)]" aria-hidden>
                          →
                        </span>
                        {h}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div
                className="absolute left-6 top-2 h-3 w-3 -translate-x-1/2 rounded-full border-2 border-[var(--accent)] bg-[var(--background)] md:left-1/2"
                aria-hidden
              />
            </motion.li>
          ))}
        </ol>

        <motion.div
          className="glass-card mx-auto max-w-3xl rounded-3xl p-8 md:p-10"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="text-lg font-semibold text-[var(--foreground)]">
            Certifications
          </h3>
          <ul className="mt-6 space-y-5">
            {certifications.map((cert) => (
              <li
                key={cert.title}
                className="flex flex-col gap-1 border-l-2 border-[var(--accent)] pl-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <a
                    href={cert.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="interactive font-medium text-[var(--accent)] hover:underline"
                  >
                    {cert.title}
                  </a>
                  <p className="text-sm text-[var(--muted)]">{cert.issuer}</p>
                </div>
                <span className="text-sm text-[var(--muted)]">{cert.date}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
}

import { motion } from "framer-motion";
import { SocialLinks } from "@/components/ui/SocialLinks";
import { siteConfig } from "@/data/portfolio";

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="border-t border-[var(--border)] py-12">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
          <div className="text-center md:text-left">
            <p className="text-sm text-[var(--muted)]">
              © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
            </p>
            <a
              href={`mailto:${siteConfig.email}`}
              className="interactive mt-1 inline-block text-sm text-[var(--foreground)] hover:text-[var(--accent)]"
            >
              {siteConfig.email}
            </a>
          </div>

          <SocialLinks variant="footer" />

          <motion.button
            type="button"
            onClick={scrollToTop}
            className="interactive flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--glass)] px-4 py-2 text-sm backdrop-blur-md"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            aria-label="Back to top"
          >
            Back to top
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          </motion.button>
        </div>
      </div>
    </footer>
  );
}

import { SectionHeader } from "@/components/ui/SectionHeader";
import { SkillTag } from "@/components/ui/SkillTag";
import { SocialLinks } from "@/components/ui/SocialLinks";
import { Reveal, RevealItem } from "@/components/ui/Reveal";
import { achievements, LINKEDIN_URL, siteConfig, skills } from "@/data/portfolio";
import { motion } from "framer-motion";

export function About() {
  return (
    <section
      id="about"
      className="section-padding"
      aria-labelledby="about-heading"
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <SectionHeader
          label="About"
          title="Passionate about building what matters"
          description={siteConfig.bio}
        />

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <a
            href={LINKEDIN_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="interactive text-sm font-medium text-[var(--accent)] underline-offset-4 hover:underline"
          >
            View my LinkedIn profile →
          </a>
          <span className="text-[var(--muted)]" aria-hidden>
            ·
          </span>
          <a
            href="#education"
            className="interactive text-sm font-medium text-[var(--accent)] underline-offset-4 hover:underline"
          >
            See education & certifications →
          </a>
        </div>

        <motion.div
          className="mt-16 glass-card rounded-3xl p-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="text-lg font-semibold text-[var(--foreground)]">
            Highlights
          </h3>
          <ul className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {achievements.map((item) => (
              <li
                key={item.title}
                className="border-l-2 border-[var(--accent)] pl-4"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="font-medium text-[var(--foreground)]">
                    {item.title}
                  </span>
                  <span className="shrink-0 text-xs text-[var(--muted)]">
                    {item.year}
                  </span>
                </div>
                <p className="mt-1 text-sm text-[var(--muted)]">{item.description}</p>
              </li>
            ))}
          </ul>
        </motion.div>

        <Reveal className="mt-12" stagger as="div">
          <RevealItem className="glass-card mx-auto max-w-4xl rounded-3xl p-8 md:p-12">
            <h3 id="about-heading" className="sr-only">
              Skills
            </h3>
            <p className="mb-8 text-center text-sm font-medium tracking-widest text-[var(--muted)] uppercase">
              Interactive skill cloud
            </p>
            <ul className="flex flex-wrap justify-center gap-3">
              {skills.map((skill, i) => (
                <SkillTag key={skill} skill={skill} index={i} />
              ))}
            </ul>
          </RevealItem>
        </Reveal>

        <div className="mt-12 flex justify-center">
          <SocialLinks variant="hero" />
        </div>
      </div>
    </section>
  );
}

import { motion } from "framer-motion";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { experience } from "@/data/portfolio";

export function Experience() {
  return (
    <section
      id="experience"
      className="section-padding"
      aria-labelledby="experience-heading"
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <SectionHeader
          label="Experience"
          title="Where I've worked"
          description="Roles where I've shipped real products and grown as an engineer."
        />
        <h2 id="experience-heading" className="sr-only">
          Work history
        </h2>

        <ol className="relative mt-16 space-y-0">
          <div
            className="absolute top-0 bottom-0 left-6 w-px bg-gradient-to-b from-[var(--accent)] via-[var(--border)] to-transparent md:left-1/2 md:-translate-x-px"
            aria-hidden
          />
          {experience.map((job, index) => (
            <motion.li
              key={job.id}
              className="relative grid gap-8 pb-16 md:grid-cols-2 md:gap-12"
              initial={{ opacity: 0, x: index % 2 === 0 ? -24 : 24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div
                className={`md:col-span-1 ${index % 2 === 1 ? "md:order-2 md:text-left" : "md:text-right"}`}
              >
                <span className="text-sm font-medium text-[var(--accent)]">
                  {job.period}
                </span>
                <h3 className="mt-1 text-xl font-semibold text-[var(--foreground)]">
                  {job.role}
                </h3>
                <p className="text-[var(--muted)]">{job.company}</p>
                <p className="mt-1 text-sm text-[var(--muted)]/80">{job.location}</p>
              </div>

              <div
                className={`glass-card rounded-2xl p-6 md:col-span-1 ${index % 2 === 1 ? "md:order-1" : ""}`}
              >
                <div className="mb-4 flex items-center gap-3">
                  <img
                    src={job.logo}
                    alt=""
                    className="h-10 w-10 rounded-lg object-contain"
                    loading="lazy"
                    onError={(e) => {
                      e.currentTarget.style.visibility = "hidden";
                    }}
                  />
                  <p className="text-sm leading-relaxed text-[var(--muted)]">
                    {job.description}
                  </p>
                </div>
                <ul className="space-y-2 text-sm text-[var(--foreground)]/90">
                  {job.highlights.map((h) => (
                    <li key={h} className="flex gap-2">
                      <span className="text-[var(--accent)]" aria-hidden>
                        →
                      </span>
                      {h}
                    </li>
                  ))}
                </ul>
              </div>

              <div
                className="absolute left-6 top-2 h-3 w-3 -translate-x-1/2 rounded-full border-2 border-[var(--accent)] bg-[var(--background)] md:left-1/2"
                aria-hidden
              />
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  );
}

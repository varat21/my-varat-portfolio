import emailjs from "@emailjs/browser";
import { motion } from "framer-motion";
import { useRef, useState, type FormEvent } from "react";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { Button } from "@/components/ui/Button";
import { SocialLinks } from "@/components/ui/SocialLinks";
import { LINKEDIN_URL, siteConfig } from "@/data/portfolio";

export function Contact() {
  const formRef = useRef<HTMLFormElement>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formRef.current) return;

    const serviceId = import.meta.env.VITE_APP_EMAILJS_SERVICE_ID;
    const templateId = import.meta.env.VITE_APP_EMAILJS_TEMPLATE_ID;
    const publicKey = import.meta.env.VITE_APP_EMAILJS_PUBLIC_KEY;

    if (!serviceId || !templateId || !publicKey) {
      setStatus("error");
      return;
    }

    setStatus("loading");
    try {
      await emailjs.sendForm(serviceId, templateId, formRef.current, publicKey);
      formRef.current.reset();
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  return (
    <section
      id="contact"
      className="section-padding"
      aria-labelledby="contact-heading"
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <SectionHeader
          label="Contact"
          title="Let's build something great"
          description="Have a project in mind? Send a message or connect on LinkedIn — I typically reply within 24 hours."
        />
        <h2 id="contact-heading" className="sr-only">
          Contact form and social links
        </h2>

        {/* Primary LinkedIn CTA */}
        <motion.div
          className="mt-12 flex justify-center"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <a
            href={LINKEDIN_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="interactive group relative inline-flex items-center gap-3 overflow-hidden rounded-2xl bg-[#0A66C2] px-8 py-4 text-base font-semibold text-white shadow-xl shadow-[#0A66C2]/30 transition-all hover:brightness-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0A66C2]"
            aria-label="Connect with Varat Thapa on LinkedIn (opens in new tab)"
          >
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
              <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
            </svg>
            Connect on LinkedIn
            <span className="text-white/80 transition-transform group-hover:translate-x-0.5" aria-hidden>
              →
            </span>
          </a>
        </motion.div>
        <p className="mt-3 text-center text-sm text-[var(--muted)]">
          <a
            href={LINKEDIN_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-[var(--accent)] hover:underline"
          >
            linkedin.com/in/varat-thapa-606a0a122
          </a>
        </p>

        <div className="mt-16 grid gap-12 lg:grid-cols-2">
          <motion.div
            className="glass-card rounded-3xl p-8"
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <form
              ref={formRef}
              onSubmit={handleSubmit}
              className="flex flex-col gap-6"
              noValidate
            >
              <div>
                <label htmlFor="name" className="mb-2 block text-sm font-medium">
                  Name
                </label>
                <input
                  id="name"
                  name="from_name"
                  type="text"
                  required
                  autoComplete="name"
                  className="input-field"
                  placeholder="Your name"
                />
              </div>
              <div>
                <label htmlFor="email" className="mb-2 block text-sm font-medium">
                  Email
                </label>
                <input
                  id="email"
                  name="from_email"
                  type="email"
                  required
                  autoComplete="email"
                  className="input-field"
                  placeholder="you@example.com"
                />
              </div>
              <div>
                <label htmlFor="message" className="mb-2 block text-sm font-medium">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={5}
                  className="input-field resize-none"
                  placeholder="Tell me about your project..."
                />
              </div>
              <Button
                type="submit"
                variant="primary"
                disabled={status === "loading"}
                className="w-full"
              >
                {status === "loading" ? "Sending..." : "Send Message"}
              </Button>
              {status === "success" && (
                <p className="text-center text-sm text-emerald-500" role="status">
                  Message sent successfully!
                </p>
              )}
              {status === "error" && (
                <p className="text-center text-sm text-red-400" role="alert">
                  Could not send. Check your EmailJS env vars in .env
                </p>
              )}
            </form>
          </motion.div>

          <motion.aside
            className="flex flex-col justify-center"
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <p className="text-lg text-[var(--muted)]">
              Prefer email? Reach me at{" "}
              <a
                href={`mailto:${siteConfig.email}`}
                className="interactive font-medium text-[var(--accent)] hover:underline"
              >
                {siteConfig.email}
              </a>
            </p>
            <div className="mt-8">
              <p className="mb-4 text-sm font-medium text-[var(--foreground)]">
                Follow & connect
              </p>
              <SocialLinks />
            </div>
          </motion.aside>
        </div>
      </div>
    </section>
  );
}

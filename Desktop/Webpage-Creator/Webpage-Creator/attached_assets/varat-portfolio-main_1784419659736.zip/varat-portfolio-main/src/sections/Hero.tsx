import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Button } from "@/components/ui/Button";
import { RoleRotator } from "@/components/ui/RoleRotator";
import { SocialLinks } from "@/components/ui/SocialLinks";
import { LINKEDIN_URL, siteConfig, stats } from "@/data/portfolio";

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <section
      id="hero"
      ref={ref}
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden pt-24 pb-16"
      aria-label="Introduction"
    >
      <motion.div
        className="pointer-events-none absolute inset-0 -z-10"
        style={{ y: bgY, opacity }}
        aria-hidden
      >
        <div className="hero-glow absolute top-1/4 left-1/2 h-[500px] w-[500px] -translate-x-1/2 rounded-full blur-[120px]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--accent-glow)_0%,_transparent_55%)]" />
      </motion.div>

      <div className="mx-auto max-w-6xl px-5 text-center md:px-8">
        <motion.p
          className="mb-6 text-sm font-medium tracking-widest text-[var(--accent)] uppercase"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {siteConfig.location} · Open to opportunities
        </motion.p>

        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-7xl lg:text-8xl">
          <motion.span
            className="block text-[var(--foreground)]"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            {siteConfig.name}
          </motion.span>
          <motion.span
            className="mt-3 block text-2xl font-medium sm:text-3xl md:text-4xl"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
          >
            <RoleRotator />
          </motion.span>
        </h1>

        <motion.p
          className="mx-auto mt-8 max-w-2xl text-lg leading-relaxed text-[var(--muted)]"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          {siteConfig.tagline}
        </motion.p>

        <motion.div
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.55 }}
        >
          <Button href="#projects" variant="primary">
            View Projects
          </Button>
          <Button href={LINKEDIN_URL} variant="outline">
            View my LinkedIn
          </Button>
        </motion.div>

        <motion.div
          className="mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          <SocialLinks variant="hero" />
        </motion.div>

        <motion.ul
          className="mt-16 grid grid-cols-2 gap-6 sm:grid-cols-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          aria-label="Career statistics"
        >
          {stats.map((stat, i) => (
            <motion.li
              key={stat.label}
              className="glass-card rounded-2xl p-5"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 + i * 0.08 }}
            >
              <span className="block text-2xl font-bold text-[var(--foreground)] md:text-3xl">
                {stat.value}
              </span>
              <span className="mt-1 block text-xs text-[var(--muted)] sm:text-sm">
                {stat.label}
              </span>
            </motion.li>
          ))}
        </motion.ul>
      </div>

      <motion.a
        href="#about"
        className="interactive absolute bottom-8 left-1/2 -translate-x-1/2 text-[var(--muted)]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 8, 0] }}
        transition={{ delay: 1.2, y: { repeat: Infinity, duration: 2 } }}
        aria-label="Scroll to about section"
      >
        <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </motion.a>
    </section>
  );
}

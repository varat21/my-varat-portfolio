import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { testimonials } from "@/data/portfolio";

export function Testimonials() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActive((i) => (i + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const current = testimonials[active];

  return (
    <section
      id="testimonials"
      className="section-padding"
      aria-labelledby="testimonials-heading"
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <SectionHeader
          label="Testimonials"
          title="What clients say"
          description="Feedback from people I've collaborated with on real projects."
        />
        <h2 id="testimonials-heading" className="sr-only">
          Client testimonials carousel
        </h2>

        <div className="relative mt-16 min-h-[280px]">
          <AnimatePresence mode="wait">
            <motion.blockquote
              key={current.id}
              className="glass-card mx-auto max-w-3xl rounded-3xl p-8 text-center md:p-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
            >
              <p className="text-lg leading-relaxed text-[var(--foreground)] md:text-xl">
                &ldquo;{current.quote}&rdquo;
              </p>
              <footer className="mt-8 flex flex-col items-center gap-3">
                <img
                  src={current.avatar}
                  alt=""
                  className="h-14 w-14 rounded-full object-cover ring-2 ring-[var(--accent)]/30"
                  loading="lazy"
                  onError={(e) => {
                    e.currentTarget.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(current.name)}&background=6366f1&color=fff`;
                  }}
                />
                <cite className="not-italic">
                  <span className="block font-semibold text-[var(--foreground)]">
                    {current.name}
                  </span>
                  <span className="text-sm text-[var(--muted)]">{current.handle}</span>
                </cite>
              </footer>
            </motion.blockquote>
          </AnimatePresence>

          <div
            className="mt-8 flex justify-center gap-2"
            role="tablist"
            aria-label="Testimonial slides"
          >
            {testimonials.map((t, i) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={i === active}
                aria-label={`Show testimonial from ${t.name}`}
                className={`interactive h-2 rounded-full transition-all ${
                  i === active
                    ? "w-8 bg-[var(--accent)]"
                    : "w-2 bg-[var(--border)] hover:bg-[var(--muted)]"
                }`}
                onClick={() => setActive(i)}
              />
            ))}
          </div>
        </div>

        <ul className="mt-16 hidden gap-6 md:grid md:grid-cols-3">
          {testimonials.slice(0, 3).map((t, i) => (
            <motion.li
              key={t.id}
              className="glass-card rounded-2xl p-6"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <p className="line-clamp-4 text-sm text-[var(--muted)]">&ldquo;{t.quote}&rdquo;</p>
              <p className="mt-4 font-medium text-[var(--foreground)]">{t.name}</p>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}

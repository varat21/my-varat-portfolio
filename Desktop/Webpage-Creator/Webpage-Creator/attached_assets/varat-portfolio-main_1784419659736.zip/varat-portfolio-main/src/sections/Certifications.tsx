import { SectionHeader } from "@/components/ui/SectionHeader";
import { certifications } from "@/data/portfolio";
import { motion } from "framer-motion";

export function Certifications() {
  return (
    <section
      id="certifications"
      className="section-padding"
      aria-labelledby="certifications-heading"
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <SectionHeader
          label="Certifications"
          title="Professional certifications"
          description="Credentials that validate my skills in SQL, React, data science, and more."
        />
        <h2 id="certifications-heading" className="sr-only">
          Certifications
        </h2>

        <div className="mt-16 grid gap-8 md:grid-cols-2">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              className="glass-card rounded-3xl p-8"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex flex-col gap-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-semibold text-[var(--foreground)]">
                      <a
                        href={cert.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="interactive hover:text-[var(--accent)] transition-colors"
                      >
                        {cert.title}
                      </a>
                    </h3>
                    <p className="mt-1 text-sm font-medium text-[var(--muted)]">
                      {cert.issuer}
                    </p>
                  </div>
                  <span className="shrink-0 text-sm text-[var(--accent)]">
                    {cert.date}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-2">
          <motion.div
            className="glass-card rounded-3xl p-8"
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold text-[var(--foreground)] mb-4">
              React
            </h3>
            <img
              src="/images/everest.png"
              alt="React"
              className="w-full h-auto rounded-2xl mb-4"
            />
          </motion.div>
          <motion.div
            className="glass-card rounded-3xl p-8"
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="text-lg font-semibold text-[var(--foreground)] mb-4">
              Data Science
            </h3>
            <img
              src="/images/broad.png"
              alt="Data Science"
              className="w-full h-auto rounded-2xl mb-4"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

# Varat Thapa — Portfolio

Production-ready portfolio built with **React 19**, **Vite 6**, **TypeScript**, **Tailwind CSS v4**, **Framer Motion**, and **Lenis** smooth scrolling.

## Features

- Dark mode by default with light mode toggle (respects system preference)
- Glassmorphism, gradient accents, noise texture overlay
- Custom cursor on desktop
- Scroll-triggered animations and 3D tilt project cards
- EmailJS contact form
- SEO meta tags, Open Graph, JSON-LD structured data
- PWA manifest and custom 404 page

## Quick start

```bash
npm install
cp .env.example .env
# Add your EmailJS keys to .env
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Environment variables

| Variable | Description |
|----------|-------------|
| `VITE_APP_EMAILJS_SERVICE_ID` | EmailJS service ID |
| `VITE_APP_EMAILJS_TEMPLATE_ID` | EmailJS template ID |
| `VITE_APP_EMAILJS_PUBLIC_KEY` | EmailJS public key |

Get credentials at [emailjs.com](https://www.emailjs.com/). Form fields: `from_name`, `from_email`, `message`.

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start dev server |
| `npm run build` | Type-check + production build |
| `npm run preview` | Preview production build |

## Deploy (Vercel / Netlify)

1. Push to GitHub
2. Connect repo — build command: `npm run build`, output: `dist`
3. Add environment variables in the dashboard
4. Deploy

## Profile links

| Link | URL |
|------|-----|
| **LinkedIn** | https://www.linkedin.com/in/varat-thapa-606a0a122/ |
| **GitHub** | https://github.com/varat-thapa |

## Customize content

Edit `src/data/portfolio.ts` for bio, projects, experience, and email (`varat@example.com` → your real address).

Add project images to `public/images/` (`project1.png`, `project2.png`, etc.).

## Lighthouse tips

- Replace `#` project URLs with real links
- Add optimized `fav.png` (192×192+)
- Serve over HTTPS in production
- Update social URLs in `portfolio.ts`
